package com.green.bank.database;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

 
public class JDBC_Connect {
	private Connection connection = null;
	static ResourceBundle rb = ResourceBundle.getBundle("com.green.bank.database.db");
	
	public Connection getConnection() throws SQLException {
		try {
			
			Class.forName(rb.getString("driverName"));
			System.out.println("Database connection before calling");
			connection = DriverManager.getConnection(rb.getString("connectionString"),rb.getString("username"),rb.getString("password"));
			System.out.println("Database connection success");

			//Class.forName("oracle.jdbc.driver.OracleDriver");
			//connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "pial", "p1207045");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();

		}

		return connection;

	}

}
