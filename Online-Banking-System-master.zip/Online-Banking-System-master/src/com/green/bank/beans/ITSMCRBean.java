package com.green.bank.beans;

import java.io.InputStream;
import java.io.Serializable;

public class ITSMCRBean implements Serializable{
	
	public ITSMCRBean() {}
	
	private String changeId;
	private String requestorName;
	private String changetitle;
	private String cabdate;
	private String crclosuredate;
	private String entity;
	private String downtime;
	private String cabcomments;
	private String application;
	private String status;
	 
	
	
	public String getCrclosuredate() {
		return crclosuredate;
	}



	public void setCrclosuredate(String crclosuredate) {
		this.crclosuredate = crclosuredate;
	}



	public String getEntity() {
		return entity;
	}



	public void setEntity(String entity) {
		this.entity = entity;
	}



	public String getDowntime() {
		return downtime;
	}



	public void setDowntime(String downtime) {
		this.downtime = downtime;
	}



	public String getCabcomments() {
		return cabcomments;
	}



	public void setCabcomments(String cabcomments) {
		this.cabcomments = cabcomments;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public ITSMCRBean(String changeId, String requestorName, String changetitle, String cabdate,String application) {
		super();
		this.changeId = changeId;
		this.requestorName = requestorName;
		this.changetitle = changetitle;
		this.cabdate = cabdate;
		this.application = application;
		 
	}



	public String getChangeId() {
		return changeId;
	}



	public void setChangeId(String changeId) {
		this.changeId = changeId;
	}



	public String getRequestorName() {
		return requestorName;
	}



	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}



	public String getChangetitle() {
		return changetitle;
	}



	public void setChangetitle(String changetitle) {
		this.changetitle = changetitle;
	}



	public String getCabdate() {
		return cabdate;
	}



	public void setCabdate(String cabdate) {
		this.cabdate = cabdate;
	}



	public String getApplication() {
		return application;
	}



	public void setApplication(String application) {
		this.application = application;
	}
	 
	
}
