package com.aub.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ConnectionFactory {

	static ResourceBundle rb = ResourceBundle.getBundle("com.aub.util.database");
	// static reference to itself
	private static ConnectionFactory instance = new ConnectionFactory();


	// private constructor
	private ConnectionFactory()
	{
		try {
			Class.forName(rb.getString("driverName"));
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static ConnectionFactory getInstance()
	{
		return instance;
	}

	public Connection getConnection() throws SQLException, ClassNotFoundException
	{		 
		System.out.println("Database connection before calling");		
		Connection connection = DriverManager.getConnection(rb.getString("connectionString"),rb.getString("username"),rb.getString("password"));
		System.out.println("Database connection success");
		return connection;
	}
}

