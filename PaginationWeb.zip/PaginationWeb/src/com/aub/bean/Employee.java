package com.aub.bean;

public class Employee {
	int employeeId;
	String employeeName;
	int salary;
	String deptName;

	public String getDeptName() { return deptName; }

	public void setDeptName(String deptName)
	{
		this.deptName = deptName;
	}

	public int getEmployeeId() { return employeeId; }

	public void setEmployeeId(int employeeId)
	{
		this.employeeId = employeeId;
	}

	public String getEmployeeName() { return employeeName; }

	public void setEmployeeName(String employeeName)
	{
		this.employeeName = employeeName;
	}

	public int getSalary() { return salary; }

	public void setSalary(int salary)
	{
		this.salary = salary;
	}
}
