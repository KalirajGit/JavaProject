package com.green.bank.model;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


import com.green.bank.beans.ITSMCRBean;
 

public interface ITSMCRDao {

	//public String addCR(String changeId, String requestorName, String changetitle, String cabdate,String application);
	
	//public String addCR(ITSMCRBean CRdetails);
	
	public List<ITSMCRBean> getAllCRs();	
	
	public ArrayList<String> getApplicationName();
	
	public List<ITSMCRBean> getApplicationCRs(String application, String status);
	
	public List<ITSMCRBean> getRequstorNameCRs(String reqname, String status);
	
	public List<ITSMCRBean> getStatusCRs(String status);
	
	public List<ITSMCRBean> getCABDateCRs(String cabdate, String status);
	
	public ArrayList<String> getRequestorName();
	
	public ArrayList<String> getStatus();
	
	public ITSMCRBean getCRDetails(String changeId);
	
	public String updateCRDetails(String changeId,ITSMCRBean CrDetails);
}
