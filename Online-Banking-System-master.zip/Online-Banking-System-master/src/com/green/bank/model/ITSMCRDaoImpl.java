package com.green.bank.model;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.green.bank.beans.ITSMCRBean;
import com.green.bank.database.JDBC_Connect;
 
 

public class ITSMCRDaoImpl implements ITSMCRDao{

	
	@Override
	public List<ITSMCRBean> getAllCRs() {
		List<ITSMCRBean> CrBeanList = new ArrayList<ITSMCRBean>();
		
	 	
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;	 
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			con = connect.getConnection();
			ps = con.prepareStatement("select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR");
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				ITSMCRBean CrDetails = new ITSMCRBean();
				
				CrDetails.setChangeId(rs.getString(1));
				CrDetails.setRequestorName(rs.getString(2));
				CrDetails.setChangetitle(rs.getString(3));
				CrDetails.setCabdate(rs.getString(4));
				CrDetails.setApplication(rs.getString(5));
				CrDetails.setStatus(rs.getString(6));
				 
				
				CrBeanList.add(CrDetails);
				
			}
			
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		 
		return CrBeanList;
	}
	
	@Override
	public ITSMCRBean getCRDetails(String changeid) {
		
		ITSMCRBean CrDetails=null;
		
		 
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			con = connect.getConnection();
			ps = con.prepareStatement("select CR_Number,Requestor_Name,Title,CAB_date,CRClosure_date,Status,Entity,Downtime,CAB_comments,Application from ITSM_CR where CR_Number=?");
			
			ps.setString(1, changeid);
			rs = ps.executeQuery();
			
			if(rs.next()) {		 
				
				
				CrDetails = new ITSMCRBean();
				
				CrDetails.setChangeId(rs.getString(1));
				CrDetails.setRequestorName(rs.getString(2));
				CrDetails.setChangetitle(rs.getString(3));
				CrDetails.setCabdate(rs.getString(4));
				CrDetails.setCrclosuredate(rs.getString(5));
				CrDetails.setStatus(rs.getString(6));
				CrDetails.setEntity(rs.getString(7));
				CrDetails.setDowntime(rs.getString(8));
				CrDetails.setCabcomments(rs.getString(9));
				CrDetails.setApplication(rs.getString(10));				 
				
			}
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	 
		
		return CrDetails;
		
		
	}
	
	@Override
	public String updateCRDetails(String changeid, ITSMCRBean CrDetails ) {		
		 
		String status = "CR Updation Failed!";
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			//ps = con.prepareStatement("select CR_Number,Requestor_Name,Title,CAB_date,CRClosure_date,Status,Entity,Downtime,CAB_comments,Application from ITSM_CR where CR_Number=?");
			con = connect.getConnection();
			ps = con.prepareStatement("update ITSM_CR set Requestor_Name=?,Title=?,CAB_date=?,CRClosure_date=?,Status=?,Entity=?,Downtime=?,CAB_comments=?,Application=? where CR_Number=?");
			
			 
			
			ps.setString(1, CrDetails.getRequestorName());
			ps.setString(2, CrDetails.getChangetitle());
			ps.setString(3, CrDetails.getCabdate());
			ps.setString(4, CrDetails.getCrclosuredate());
			ps.setString(5, CrDetails.getStatus());
			ps.setString(6, CrDetails.getEntity());
			ps.setString(7, CrDetails.getDowntime());
			ps.setString(8, CrDetails.getCabcomments());
			ps.setString(9, CrDetails.getApplication());
			ps.setString(10, CrDetails.getChangeId());
			 
			int k = ps.executeUpdate();
			
			if((k>0)) {
				status = "CR Details Updated Successfully!";
			}
			
			 	 
			con.close();
			ps.close();
			rs.close();	
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	 
		
		return status;
		
		
	}
	 
	@Override
	public List<ITSMCRBean> getApplicationCRs(String Application, String status) {
		List<ITSMCRBean> CrBeanList = new ArrayList<ITSMCRBean>();
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql=null;
		String newStatus=null;
		try {
			con = connect.getConnection();
			
			if(status.equals("Closed")){
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where Application=? and Status=?";
				 newStatus=status;
				ps = con.prepareStatement(sql);
				ps.setString(1, Application);
				ps.setString(2, newStatus);	
			}else if(status.equals("All")){
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where Application=?";
				 newStatus=status;
				ps = con.prepareStatement(sql);
				ps.setString(1, Application);				 
			}else {
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where Application=? and Status<>?";
				 newStatus="Closed";	
				ps = con.prepareStatement(sql);
				ps.setString(1, Application);
				ps.setString(2, newStatus);	
			}
			
			System.out.println("Query :" + sql);
	 
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				ITSMCRBean CrDetails = new ITSMCRBean();
				
				CrDetails.setChangeId(rs.getString(1));
				CrDetails.setRequestorName(rs.getString(2));
				CrDetails.setChangetitle(rs.getString(3));
				CrDetails.setCabdate(rs.getString(4));
				CrDetails.setApplication(rs.getString(5));
				CrDetails.setStatus(rs.getString(6));
				 
				
				CrBeanList.add(CrDetails);
				
			}
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	 
		
		return CrBeanList;
	}
	
	@Override
	public ArrayList<String> getApplicationName() {
		 
		ArrayList<String> appNameList = new ArrayList<String>();
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = connect.getConnection();
			ps = con.prepareStatement("select distinct Application from ITSM_CR");
			 
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				appNameList.add(rs.getString(1));		 
				 
				 
			}
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
 
		
		return appNameList;
	}
	
	@Override
	public ArrayList<String> getRequestorName() {
		 
		ArrayList<String> reqNameList = new ArrayList<String>();
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = connect.getConnection();
			ps = con.prepareStatement("select distinct Requestor_name from ITSM_CR");
			 
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				reqNameList.add(rs.getString(1));		 
				 
				 
			}
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
 
		
		return reqNameList;
	}
	
	@Override
	public ArrayList<String> getStatus() {
		 
		ArrayList<String> StatusList = new ArrayList<String>();
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = connect.getConnection();
			ps = con.prepareStatement("select distinct Status from ITSM_CR");
			 
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				StatusList.add(rs.getString(1));					 
				 
			}
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		 
		
		return StatusList;
	}
	
	@Override
	public List<ITSMCRBean> getRequstorNameCRs(String reqname, String status) {
		List<ITSMCRBean> CrBeanList = new ArrayList<ITSMCRBean>();
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql=null;
		String newStatus=null;
		
		try {
			con = connect.getConnection();
			if(status.equals("Closed")){
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where Requestor_name=? and Status=?";
				 newStatus=status;
				ps = con.prepareStatement(sql);
				ps.setString(1, reqname);
				ps.setString(2, newStatus);	
			}else if(status.equals("All")){
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where Requestor_name=?";
				 newStatus=status;
				ps = con.prepareStatement(sql);
				ps.setString(1, reqname);				 
			}else {
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where Requestor_name=? and Status<>?";
				 newStatus="Closed";	
				ps = con.prepareStatement(sql);
				ps.setString(1, reqname);
				ps.setString(2, newStatus);	
			}
			
			System.out.println("Query :" + sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				ITSMCRBean CrDetails = new ITSMCRBean();
				
				CrDetails.setChangeId(rs.getString(1));
				CrDetails.setRequestorName(rs.getString(2));
				CrDetails.setChangetitle(rs.getString(3));
				CrDetails.setCabdate(rs.getString(4));
				CrDetails.setApplication(rs.getString(5));
				CrDetails.setStatus(rs.getString(6));
				 
				
				CrBeanList.add(CrDetails);
				
			}
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		 
		
		return CrBeanList;
	}
	
	@Override
	public List<ITSMCRBean> getStatusCRs(String status) {
		List<ITSMCRBean> CrBeanList = new ArrayList<ITSMCRBean>();
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			con = connect.getConnection();
			ps = con.prepareStatement("select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where Status=?");
			ps.setString(1, status);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				ITSMCRBean CrDetails = new ITSMCRBean();
				
				CrDetails.setChangeId(rs.getString(1));
				CrDetails.setRequestorName(rs.getString(2));
				CrDetails.setChangetitle(rs.getString(3));
				CrDetails.setCabdate(rs.getString(4));
				CrDetails.setApplication(rs.getString(5));
				CrDetails.setStatus(rs.getString(6));
				 
				
				CrBeanList.add(CrDetails);
				
			}
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		 
		
		return CrBeanList;
	}
	
	@Override
	public List<ITSMCRBean> getCABDateCRs(String cabdate, String status) {
		List<ITSMCRBean> CrBeanList = new ArrayList<ITSMCRBean>();
		
		System.out.println("CAB Date :" + cabdate);
		
		JDBC_Connect connect = new JDBC_Connect();
		Connection con = null;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql=null;
		String newStatus=null;
		try {
			con = connect.getConnection();
			if(status.equals("Closed")){
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where CAB_date=? and Status=?";
				 newStatus=status;
				ps = con.prepareStatement(sql);
				ps.setString(1, cabdate);
				ps.setString(2, newStatus);	
			}else if(status.equals("All")){
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where CAB_date=?";
				 newStatus=status;
				ps = con.prepareStatement(sql);
				ps.setString(1, cabdate);				 
			}else {
				 sql="select CR_Number,Requestor_Name,Title,CAB_date,Application,Status from ITSM_CR where CAB_date=? and Status<>?";
				 newStatus="Closed";	
				ps = con.prepareStatement(sql);
				ps.setString(1, cabdate);
				ps.setString(2, newStatus);	
			}
			
			System.out.println("Query :" + sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				ITSMCRBean CrDetails = new ITSMCRBean();
				
				CrDetails.setChangeId(rs.getString(1));
				CrDetails.setRequestorName(rs.getString(2));
				CrDetails.setChangetitle(rs.getString(3));
				CrDetails.setCabdate(rs.getString(4));
				CrDetails.setApplication(rs.getString(5));
				CrDetails.setStatus(rs.getString(6));
				 
				
				CrBeanList.add(CrDetails);
				
			}
			con.close();
			ps.close();
			rs.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
 
		
		return CrBeanList;
	}
}
